package T145.magistics.common.tiles;

import net.minecraft.tileentity.TileEntity;

public class TileInfusionWorkbench extends TileEntity {
}